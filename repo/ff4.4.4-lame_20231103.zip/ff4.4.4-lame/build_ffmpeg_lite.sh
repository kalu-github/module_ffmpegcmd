#!/usr/bin/env bash
export NDK=/home/kalu/download/android-ndk/r14b
export PREFIX=`pwd`/build
export SONAME=libffmpegcmd.so

echo NDK-Dir=${NDK}
echo PREFIX=${PREFIX}

root_dir=`pwd`

# configure
cd $root_dir/ffmpeg
./configure

# build
chmod +x ./build_lite.sh
./build_lite.sh
