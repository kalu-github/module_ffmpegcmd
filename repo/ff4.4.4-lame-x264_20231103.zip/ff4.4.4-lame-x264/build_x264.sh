#!/usr/bin/env bash
export NDK=/home/kalu/download/android-ndk/r14b
export PREFIX=`pwd`/build

echo NDK-Dir=${NDK}
echo PREFIX=${PREFIX}

root_dir=`pwd`
echo => build libx264 start
rm -r ./build/x264

cd $root_dir/x264
# ./configure

chmod +x ./build_android_all.sh
./build_android_all.sh

echo => build libx264 end